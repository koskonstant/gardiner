-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Φιλοξενητής: 127.0.0.1
-- Χρόνος δημιουργίας: 17 Σεπ 2017 στις 17:42:28
-- Έκδοση διακομιστή: 5.6.11
-- Έκδοση PHP: 5.5.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Βάση: `ser_game`
--
CREATE DATABASE IF NOT EXISTS `ser_game` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ser_game`;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `artifact_instances`
--

CREATE TABLE IF NOT EXISTS `artifact_instances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `artifact_type` int(10) unsigned NOT NULL,
  `artifact_name` varchar(255) NOT NULL COMMENT 'the name of the tile in the FS',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Άδειασμα δεδομένων του πίνακα `artifact_instances`
--

INSERT INTO `artifact_instances` (`id`, `artifact_type`, `artifact_name`) VALUES
(1, 1, 'Hugo'),
(2, 1, 'Judy'),
(3, 1, 'Kate'),
(4, 1, 'Mack'),
(5, 1, 'Val'),
(6, 1, 'Albert'),
(7, 1, 'Amanda'),
(8, 1, 'Andrew'),
(9, 1, 'Anthony'),
(10, 1, 'Mary'),
(11, 1, 'Alice'),
(12, 1, 'Chloe'),
(13, 1, 'Chris'),
(14, 1, 'Elisa'),
(15, 1, 'Harry'),
(16, 1, 'Irene'),
(17, 1, 'James'),
(18, 1, 'Katie'),
(19, 1, 'Mario'),
(20, 1, 'Pedro'),
(21, 1, 'Angela'),
(22, 1, 'Bianca'),
(23, 1, 'Carlos'),
(24, 1, 'Claire'),
(25, 1, 'Daniel'),
(26, 1, 'Donald'),
(27, 1, 'Elvira'),
(28, 1, 'Eugene'),
(29, 1, 'Gerald'),
(30, 1, 'Hector'),
(31, 1, 'Jessie'),
(32, 1, 'Justin'),
(33, 1, 'Kristy'),
(34, 1, 'Patric'),
(35, 1, 'Steven'),
(36, 1, 'Trevor');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `artifact_instances_level`
--

CREATE TABLE IF NOT EXISTS `artifact_instances_level` (
  `artifact_instance_id` int(10) unsigned NOT NULL,
  `level_id` varchar(45) NOT NULL,
  PRIMARY KEY (`artifact_instance_id`,`level_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `artifact_instances_level`
--

INSERT INTO `artifact_instances_level` (`artifact_instance_id`, `level_id`) VALUES
(1, '1'),
(2, '1'),
(3, '1'),
(4, '1'),
(5, '1'),
(6, '2'),
(6, '3'),
(7, '2'),
(7, '4'),
(8, '2'),
(8, '4'),
(9, '2'),
(9, '3'),
(10, '2'),
(11, '3'),
(12, '3'),
(13, '3'),
(14, '3'),
(15, '3'),
(16, '3'),
(17, '3'),
(18, '3'),
(19, '3'),
(20, '3'),
(21, '4'),
(22, '4'),
(23, '4'),
(24, '4'),
(25, '4'),
(26, '4'),
(27, '4'),
(28, '4'),
(29, '4'),
(30, '4'),
(31, '4'),
(32, '4'),
(33, '4'),
(34, '4'),
(35, '4'),
(36, '4');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `artifact_instances_locale`
--

CREATE TABLE IF NOT EXISTS `artifact_instances_locale` (
  `artifact_instance_id` int(10) unsigned NOT NULL,
  `locale_id` int(10) unsigned NOT NULL,
  `artifact_path` varchar(255) DEFAULT NULL,
  `artifact_obj` blob,
  `artifact_name` varchar(255) NOT NULL,
  `artifact_mime_type` varchar(45) NOT NULL,
  `artifact_level_id` int(11) NOT NULL,
  `artifact_cat` varchar(50) NOT NULL,
  `artifact_aud` varchar(150) NOT NULL,
  PRIMARY KEY (`artifact_instance_id`,`locale_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `artifact_instances_locale`
--

INSERT INTO `artifact_instances_locale` (`artifact_instance_id`, `locale_id`, `artifact_path`, `artifact_obj`, `artifact_name`, `artifact_mime_type`, `artifact_level_id`, `artifact_cat`, `artifact_aud`) VALUES
(1, 1, 'images/faces/Albert.png', NULL, 'Albert', 'jpg', 1, 'faces', 'mp3/faces/Bianca.mp3'),
(2, 1, 'images/faces/Alice.png', NULL, 'Alice', 'jpg', 1, 'faces', 'mp3/faces/Alice.mp3'),
(3, 1, 'images/faces/Kate.png', NULL, 'Kate', 'jpg', 1, 'faces', 'mp3/faces/Kate.mp3'),
(7, 1, 'images/faces/Amanda.png', NULL, 'Amanda', 'jpg', 1, 'faces', 'mp3/faces/Amanda.mp3'),
(8, 1, 'images/faces/Andrew.png', NULL, 'Andrew', 'jpg', 0, 'faces', 'mp3/faces/Andrew.mp3'),
(9, 1, 'images/faces/Anthony.png', NULL, 'Anthony', 'jpg', 0, 'faces', 'mp3/faces/Anthony.mp3'),
(10, 1, 'images/faces/Mary.png', NULL, 'Mary', 'jpg', 0, 'faces', 'mp3/faces/Mary.mp3'),
(11, 1, 'images/faces/Alice.png', NULL, 'Alice', 'jpg', 0, 'faces', 'mp3/faces/Alice.mp3'),
(12, 1, 'images/faces/Chloe.png', NULL, 'Chloe', 'jpg', 0, 'faces', 'mp3/faces/Chloe.mp3'),
(13, 1, 'images/faces/Chris.png', NULL, 'Chris', 'jpg', 0, 'faces', 'mp3/faces/Chris.mp3'),
(14, 1, 'images/faces/Elisa.png', NULL, 'Elisa', 'jpg', 0, 'faces', 'mp3/faces/Elisa.mp3'),
(17, 1, 'images/faces/James.png', NULL, 'James', 'jpg', 0, 'faces', 'mp3/faces/James.mp3'),
(21, 1, 'images/faces/Angela.png', NULL, 'Angela', 'jpg', 0, 'faces', 'mp3/faces/Angela.mp3'),
(22, 1, 'images/faces/Bianca.png', NULL, 'Bianca', 'jpg', 0, 'faces', 'mp3/faces/Bianca.mp3'),
(23, 1, 'images/faces/Carlos.png', NULL, 'Carlos', 'jpg', 0, 'faces', 'mp3/faces/Carlos.mp3'),
(25, 1, 'images/faces/Daniel.png', NULL, 'Daniel', 'jpg', 0, 'faces', 'mp3/faces/Daniel.mp3'),
(26, 1, 'images/faces/Donald.png', NULL, 'Donald', 'jpg', 0, 'faces', 'mp3/faces/Donald.mp3'),
(29, 1, 'images/faces/Gerald.png', NULL, 'Gerald', 'jpg', 0, 'faces', 'mp3/faces/Gerald.mp3'),
(30, 1, 'images/faces/Hector.png', NULL, 'Hector', 'jpg', 0, 'faces', 'mp3/faces/Hector.mp3');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `artifact_types`
--

CREATE TABLE IF NOT EXISTS `artifact_types` (
  `art_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `art_type` varchar(45) NOT NULL,
  PRIMARY KEY (`art_id`) USING BTREE,
  UNIQUE KEY `art_id` (`art_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Άδειασμα δεδομένων του πίνακα `artifact_types`
--

INSERT INTO `artifact_types` (`art_id`, `art_type`) VALUES
(1, 'face'),
(2, 'color'),
(3, 'fruit');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `board_instances`
--

CREATE TABLE IF NOT EXISTS `board_instances` (
  `user_id` int(10) unsigned NOT NULL,
  `game_session_id` int(10) unsigned NOT NULL,
  `level_id` int(10) unsigned NOT NULL,
  `artifact_instance_id` int(10) unsigned NOT NULL COMMENT 'apo ton tile_instances',
  `index` int(10) unsigned NOT NULL COMMENT 'h thesh toy sto plegma'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='afora ta stigmiotypa twn pistwn poy exoyn paiksei oi paixtes.';

--
-- Άδειασμα δεδομένων του πίνακα `board_instances`
--

INSERT INTO `board_instances` (`user_id`, `game_session_id`, `level_id`, `artifact_instance_id`, `index`) VALUES
(1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Άδειασμα δεδομένων του πίνακα `country`
--

INSERT INTO `country` (`id`, `name`) VALUES
(1, 'United Kingdom'),
(2, 'Greece');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `education_levels`
--

CREATE TABLE IF NOT EXISTS `education_levels` (
  `id` int(10) unsigned NOT NULL,
  `educ_level_name` longtext NOT NULL,
  `locale_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`,`locale_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `education_levels`
--

INSERT INTO `education_levels` (`id`, `educ_level_name`, `locale_id`) VALUES
(1, 'Entry Level', 1),
(1, 'Βασικό', 2),
(2, 'Elementary School', 1),
(2, 'Δημοτικό', 2),
(3, 'Intermediate School', 1),
(3, 'Γυμνάσιο', 2),
(4, 'High School', 1),
(4, 'Λύκειο', 2),
(5, 'Advanced Education Certificate', 1),
(5, 'ΙΕΚ', 2),
(6, 'Bachelors Degree', 1),
(6, 'Πτυχίο Τριτοβάθμιας Εκπ/σης', 2),
(7, 'Masters Degree', 1),
(7, 'Πτυχίο Μάστερ', 2),
(8, 'PhD', 1),
(8, 'Διδακτορικό', 2),
(9, 'Other', 1),
(9, 'Άλλο', 2);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `edu_level`
--

CREATE TABLE IF NOT EXISTS `edu_level` (
  `EDU_Level_ID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identification of Educational Level',
  `EDU_LevelName` varchar(50) NOT NULL COMMENT 'Educational Level Name',
  `EDU_LevelDescr` varchar(200) NOT NULL COMMENT 'Education Level Description',
  `LANG_Id` int(10) unsigned NOT NULL COMMENT 'Identification of language',
  PRIMARY KEY (`EDU_Level_ID`,`LANG_Id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Άδειασμα δεδομένων του πίνακα `edu_level`
--

INSERT INTO `edu_level` (`EDU_Level_ID`, `EDU_LevelName`, `EDU_LevelDescr`, `LANG_Id`) VALUES
(1, 'ISCED 0', 'Early childhood education (‘less than primary’ for educational attainment', 1),
(2, 'ISCED 1', 'Primary education', 1),
(3, 'ISCED 2', 'Lower secondary education', 1),
(4, 'ISCED 3', 'Upper secondary education', 1),
(5, 'ISCED 4', 'Post-secondary non-tertiary education', 1),
(6, 'ISCED 5', 'Short-cycle tertiary education', 1),
(7, 'ISCED 6', 'Bachelor’s or equivalent level', 1),
(8, 'ISCED 7', 'Master’s or equivalent level', 1),
(9, 'ISCED 8', 'Doctoral or equivalent level', 1),
(10, 'Επίπεδο 0', 'Νηπιαγωγείου ', 2),
(11, 'Επίπεδο 1', 'Απολυτήριο Δημοτικού', 2),
(12, 'Επίπεδο 2', 'Απολυτήριο Γυμνασίου', 2),
(13, 'Επίπεδο 3', 'Πτυχίο Επαγγελματικής Eιδικότητας επιπέδου 3 ΣΕΚ ή Πιστοποιητικό Επαγγελματικής Κατάρτισης επιπέδου 1 ΙΕΚ', 2),
(14, 'Επίπεδο 4', 'Πτυχίο ΕΠΑΣ ή Πτυχίο Επαγγελματικής Ειδικότητας επιπέδου 3 ΕΠΑΛ  ή Απολυτήριο Επαγγελματικού Λυκείου ΕΠΑΛ ή Απολυτήριο Γενικού Λυκείου', 2),
(15, 'Επίπεδο 5', 'Πτυχίο Επαγγελματικής Ειδικότητας επιπέδου 4 ΕΠΑΛ ή Δίπλωμα Επαγγελματικής Ειδικότητας επιπέδου 4 ΙΕΚ ή Δίπλωμα - Πτυχίο Ανωτέρας Σχολής', 2),
(16, 'Επίπεδο 6', 'Πτυχίο ΑΕΙ ή Πτυχίο ΤΕΙ ή Πτυχίο Ανώτατης Εκπαίδευσης (πενταετείς σπουδές ή στρατιωτικές σχολές)', 2),
(17, 'Επίπεδο 7', 'Μεταπτυχιακό Δίπλωμα Ειδίκευσης ή αλλιώς Master', 2),
(18, 'Επίπεδο 8', 'Διδακτορικό Δίπλωμα', 2);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `games`
--

CREATE TABLE IF NOT EXISTS `games` (
  `game_id` int(11) NOT NULL AUTO_INCREMENT,
  `game_name` varchar(100) NOT NULL,
  PRIMARY KEY (`game_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Άδειασμα δεδομένων του πίνακα `games`
--

INSERT INTO `games` (`game_id`, `game_name`) VALUES
(1, 'game1'),
(2, 'game2');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `game_sessions`
--

CREATE TABLE IF NOT EXISTS `game_sessions` (
  `user_id` int(10) unsigned NOT NULL,
  `game_session_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `start_datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `locale_id` int(10) unsigned NOT NULL COMMENT 'to locale me to opoio ksekinhse na paizei to game session. Gia istorikoys logoyw epeidh mporei na allaksei to krataw ksexwrista gia kathe paixnidi poy paizei.',
  `game_level` int(11) NOT NULL,
  `game_category` int(11) NOT NULL,
  `game_clicks` text NOT NULL,
  `game_moves` int(11) NOT NULL,
  `game_time_finished` int(11) NOT NULL,
  `is_admin` tinyint(1) DEFAULT NULL,
  `game_id` int(11) NOT NULL,
  PRIMARY KEY (`game_session_id`,`user_id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Άδειασμα δεδομένων του πίνακα `game_sessions`
--

INSERT INTO `game_sessions` (`user_id`, `game_session_id`, `start_datetime`, `locale_id`, `game_level`, `game_category`, `game_clicks`, `game_moves`, `game_time_finished`, `is_admin`, `game_id`) VALUES
(9, 1, '2017-04-22 01:25:13', 1, 2, 2, 'tile1 (Papaya): 2 Clicks  tile2 (Melon): 5 Clicks  tile3 (Pear): 2 Clicks  tile4 (Melon): 3 Clicks  tile5 (Pear): 2 Clicks  tile6 (Papaya): 2 Clicks  tile7 (Apricot): 5 Clicks  tile8 (Apricot): 2 Clicks ', 10, 27, 1, 1),
(15, 1, '2017-09-17 17:11:25', 0, 1, 2, 'tile1 (Papaya): 2 Clicks tile2 (Melon): 5 Clicks tile3 (Pear): 2 Clicks tile4 (Melon): 3 Clicks tile5 (Pear): 2 Clicks tile6 (Papaya): 2 Clicks tile7 (Apricot): 5 Clicks tile8 (Apricot): 2 Clicks ', 18, 35, 1, 1),
(15, 2, '2017-04-22 01:25:13', 1, 1, 1, 'tile1 (Papaya): 2 Clicks  tile2 (Melon): 5 Clicks  tile3 (Pear): 2 Clicks  tile4 (Melon): 3 Clicks  tile5 (Pear): 2 Clicks  tile6 (Papaya): 2 Clicks  tile7 (Apricot): 5 Clicks  tile8 (Apricot): 2 Clicks ', 12, 30, NULL, 2),
(15, 3, '2017-09-07 00:00:00', 2, 3, 3, 'tile1 (Papaya): 2 Clicks tile2 (Melon): 5 Clicks tile3 (Pear): 2 Clicks tile4 (Melon): 3 Clicks tile5 (Pear): 2 Clicks tile6 (Papaya): 2 Clicks tile7 (Apricot): 5 Clicks tile8 (Apricot): 2 Clicks ', 12, 27, NULL, 2);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `LANG_Id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identification of language',
  `LANG_Def` varchar(45) NOT NULL COMMENT 'Definition of language',
  PRIMARY KEY (`LANG_Id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Άδειασμα δεδομένων του πίνακα `language`
--

INSERT INTO `language` (`LANG_Id`, `LANG_Def`) VALUES
(1, 'English'),
(2, 'Greek');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `levels`
--

CREATE TABLE IF NOT EXISTS `levels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `difficulty_class` varchar(45) NOT NULL,
  `difficulty_characterization` varchar(45) NOT NULL,
  `number_of_artifacts` int(10) unsigned NOT NULL,
  `game_id` int(11) NOT NULL,
  `game_difficulty` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Άδειασμα δεδομένων του πίνακα `levels`
--

INSERT INTO `levels` (`id`, `difficulty_class`, `difficulty_characterization`, `number_of_artifacts`, `game_id`, `game_difficulty`) VALUES
(1, '1', 'Level 1', 9, 2, '2*4 Tiles'),
(2, '2', 'Level 2', 9, 2, '3*6 Tiles'),
(3, '3', 'Level 3', 25, 2, '4*8 Tiles');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `memberID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `USR_DoB` datetime NOT NULL COMMENT 'User Date of Birth',
  `USR_Gender_Id` varchar(10) NOT NULL COMMENT 'User Gender',
  `USR_ProfilePicture` varchar(45) DEFAULT NULL,
  `USR_FName` varchar(45) NOT NULL COMMENT 'User First Name',
  `USR_MName` varchar(45) DEFAULT NULL COMMENT 'User Middle Name',
  `USR_LName` varchar(45) NOT NULL COMMENT 'User Last Name',
  `USR_PoB` varchar(45) DEFAULT NULL COMMENT 'User Place of Birth Country',
  `USR_Race` varchar(45) DEFAULT NULL COMMENT 'User Race (e.g. Caucasian)',
  `USR_ResAddrStreet` varchar(100) DEFAULT NULL COMMENT 'User Residence Address Street',
  `USR_ResAddrZip` int(10) unsigned DEFAULT NULL COMMENT 'User Residence Address Zip Code',
  `USR_ResAddrCity` varchar(45) DEFAULT NULL COMMENT 'User Residence Address City',
  `USR_ResAddrState` varchar(45) DEFAULT NULL COMMENT 'User Residence Address State',
  `USR_ResAddrCountry` varchar(45) DEFAULT NULL COMMENT 'User Residence Address Country',
  `USR_PhoneNum` int(10) unsigned DEFAULT NULL COMMENT 'User Phone Numbers',
  `USR_ProfileURL` varchar(100) DEFAULT NULL,
  `USR_WebsiteURL` varchar(100) DEFAULT NULL,
  `Lang_ID` int(10) unsigned NOT NULL COMMENT 'Default Usage User Language ',
  `USR_Work` varchar(100) DEFAULT NULL COMMENT 'User Work History/Details',
  `USR_Interests` varchar(100) DEFAULT NULL,
  `active` varchar(255) NOT NULL,
  `resetToken` varchar(255) DEFAULT NULL,
  `resetComplete` varchar(3) DEFAULT 'No',
  `is_admin` int(1) NOT NULL,
  PRIMARY KEY (`memberID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Άδειασμα δεδομένων του πίνακα `members`
--

INSERT INTO `members` (`memberID`, `username`, `password`, `email`, `USR_DoB`, `USR_Gender_Id`, `USR_ProfilePicture`, `USR_FName`, `USR_MName`, `USR_LName`, `USR_PoB`, `USR_Race`, `USR_ResAddrStreet`, `USR_ResAddrZip`, `USR_ResAddrCity`, `USR_ResAddrState`, `USR_ResAddrCountry`, `USR_PhoneNum`, `USR_ProfileURL`, `USR_WebsiteURL`, `Lang_ID`, `USR_Work`, `USR_Interests`, `active`, `resetToken`, `resetComplete`, `is_admin`) VALUES
(9, 'kostas', '$2y$10$cSCReDWo47HogwJr3pX8Fuoh/aSD3oXW/SOxncsDTF7qXCTA4xase', 'fsfd@fsdsd.fds', '0000-00-00 00:00:00', 'M', '456', 'kostas', 'N', 'Konstantoulakis', 'fsdff', 'sdf', NULL, 0, 'sdf', 'sdf', 'sfd', 456, NULL, 'fsdf', 0, 'sdf', 'sdf', 'Yes', NULL, 'No', 1),
(13, 'maria', '$2y$10$hw40XSsmBQ0wZ7iDNoMKDezGi3NF2EWlrFzD/Oesf773/3Os5j7g.', 'maria@test.gr', '0000-00-00 00:00:00', 'M', 'ict', 'Maria', 'Rena', 'Skalidaki', 'Heraklion', 'Dikiosunhs', NULL, 71409, 'Heraklion', 'Crete', 'Heraklion', 6544645, NULL, 'ict', 0, 'student', 'test', 'Yes', NULL, 'No', 0),
(14, 'teest', '$2y$10$yZosrpMxs3Z5Dht8qAjfWepetKhoVutxiXJvQOFlmQi8Fj0NA.8xS', 'fsdf@gdg.gdf', '0000-00-00 00:00:00', 'M', NULL, 'test', 'teest', 'teest', 'teest', NULL, 'teest', 0, 'teest', 'teest', 'teest', 5456, 'teest', 'teest', 0, 'teest', 'teest', 'b13ae728713ce0d5143ebddccc0e86cb', NULL, 'No', 0),
(15, 'nikos', '$2y$10$cSCReDWo47HogwJr3pX8Fuoh/aSD3oXW/SOxncsDTF7qXCTA4xase', 'nikos@test.gr', '0000-00-00 00:00:00', 'M', NULL, 'nikos', 'kostas', 'vidakis', 'heraklion', NULL, 'tei', 71409, 'heraklion', 'crete', 'heraklion', 54545556, 'www.test.gr', 'www.test.gr', 0, 'test', 'soccer', 'Yes', NULL, 'No', 0);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `sp_edu_cat`
--

CREATE TABLE IF NOT EXISTS `sp_edu_cat` (
  `SP_EDU_CAT_Id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identification of educational needs',
  `SP_EDU_CAT_Name` varchar(45) NOT NULL COMMENT 'Category Name',
  `SP_EDU_CAT_Abbr` varchar(45) NOT NULL COMMENT 'Category abbreviation',
  `SP_EDU_CAT_Descr` varchar(255) DEFAULT NULL COMMENT 'Category Description',
  PRIMARY KEY (`SP_EDU_CAT_Id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Άδειασμα δεδομένων του πίνακα `sp_edu_cat`
--

INSERT INTO `sp_edu_cat` (`SP_EDU_CAT_Id`, `SP_EDU_CAT_Name`, `SP_EDU_CAT_Abbr`, `SP_EDU_CAT_Descr`) VALUES
(1, 'PhysDis', 'PhysDis', 'Physical disability'),
(2, 'HearImp', 'HearImp', 'Hearing impairment'),
(3, 'VisImp', 'VisImp', 'Visual impairment'),
(4, 'EmotDis', 'EmotDis', 'Emotional disturbance and/or behaviour problems'),
(5, 'SevMotDis', 'SevMotDis', 'Severe motional disturbance and/or behaviour problems'),
(6, 'MildLearnDis', 'MildLD', 'Mild general learning disability'),
(7, 'BorderLearnDis', 'BorderLD', 'Borderline general learning disability'),
(8, 'SpecifLearnDis', 'SpecifLD', 'Specific learning disability'),
(9, 'ModerLearnDis', 'ModerLD', 'Moderate general learning disability'),
(10, 'SeverLearnDis', 'SevereLD', 'Severe or profound general learning disability'),
(11, 'ASD', 'ASD', 'Autism/autistic spectrum disorder'),
(12, 'AssesSynd', 'ASyndrom', 'Pupils with special educational needs arising from an assessed syndrome'),
(13, 'SpeechLangDis', 'SpeechD', 'Specific speech and language disorder'),
(14, 'MultiDis', 'MultiDis', 'Multiple disabilities');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `user_given_hints_per_level`
--

CREATE TABLE IF NOT EXISTS `user_given_hints_per_level` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `game_session_id` int(10) unsigned NOT NULL,
  `level_id` int(10) unsigned NOT NULL,
  `artifact_id` int(10) unsigned NOT NULL COMMENT 'to artifact gia to opoio dwthike to hint',
  PRIMARY KEY (`user_id`,`game_session_id`,`level_id`,`artifact_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `user_performance_per_level`
--

CREATE TABLE IF NOT EXISTS `user_performance_per_level` (
  `user_id` int(10) unsigned NOT NULL,
  `game_session_id` int(10) unsigned NOT NULL,
  `level_id` int(10) unsigned NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `finish_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `error_count` int(10) unsigned NOT NULL,
  `hint_count` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`game_session_id`,`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `usr_education`
--

CREATE TABLE IF NOT EXISTS `usr_education` (
  `memberID` int(10) unsigned NOT NULL COMMENT 'Identification of user',
  `EDU_Level_ID` int(10) unsigned NOT NULL COMMENT 'Identification of Educational Level',
  `EXP_Abbr` varchar(50) NOT NULL COMMENT 'Experience abbreviation',
  `EXP_Descr` varchar(255) NOT NULL COMMENT 'Details of educational experience',
  PRIMARY KEY (`EDU_Level_ID`,`memberID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `usr_gender`
--

CREATE TABLE IF NOT EXISTS `usr_gender` (
  `USR-Gender_Id` int(10) unsigned NOT NULL,
  `USR-Gender_name` varchar(45) NOT NULL,
  `Lang_Id` varchar(45) NOT NULL,
  PRIMARY KEY (`USR-Gender_Id`,`Lang_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `usr_gender`
--

INSERT INTO `usr_gender` (`USR-Gender_Id`, `USR-Gender_name`, `Lang_Id`) VALUES
(1, 'Male', '1'),
(1, 'Άνδρας', '2'),
(2, 'Female', '1'),
(2, 'Γυναίκα', '2');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `usr_rl`
--

CREATE TABLE IF NOT EXISTS `usr_rl` (
  `USR_RL_Id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identification of user roles',
  `USR_RL_Name` varchar(50) NOT NULL COMMENT 'User Role Name',
  `USR_RL_Abbr` varchar(10) NOT NULL COMMENT 'User Role abbreviation',
  `USR_RL_Descr` varchar(255) NOT NULL COMMENT 'User Role Description',
  PRIMARY KEY (`USR_RL_Id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Άδειασμα δεδομένων του πίνακα `usr_rl`
--

INSERT INTO `usr_rl` (`USR_RL_Id`, `USR_RL_Name`, `USR_RL_Abbr`, `USR_RL_Descr`) VALUES
(1, 'Administrator', 'Admin', 'This is the system administration role'),
(2, 'EduExpert', 'EduEx', 'This role is for professionals on Educational that are experts in the fields of educational theories, educational styles, paedagogitsts etc.'),
(3, 'Teacher', 'Teacher', 'This role stands for the school teacher of all levels'),
(4, 'Carer', 'CarePare', 'This role is for parents that care for their children or for professional carers that look after individuals in need.'),
(5, 'Student', 'Student', 'This role is students or learners of all ages '),
(6, 'Guest', 'Guest', 'This role is for users that do not need to register to the system and they have limited access to data, games and services.');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `usr_sp_edu_needs`
--

CREATE TABLE IF NOT EXISTS `usr_sp_edu_needs` (
  `memberID` int(10) unsigned NOT NULL COMMENT 'Identification of user',
  `SP_EDU_CAT_Id` int(10) unsigned NOT NULL COMMENT 'Identification of educational needs',
  PRIMARY KEY (`memberID`,`SP_EDU_CAT_Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
